from flask import Flask, render_template, request, redirect, url_for, send_from_directory, session
from functools import wraps
from Models.Model_crud import Pasajero, Reserva, Silla, Usuario
from services import ReservaService

app = Flask(__name__)
app.secret_key = 'tu_clave_secreta'
reserva_service = ReservaService()

@app.route('/logout')
def logout():
    session.pop('usuario_id', None)
    session.pop('nombre_usuario', None)
    return redirect(url_for('index'))

def login_required():
    def wrapper(fn):
        @wraps(fn)
        def decorated_view(*args, **kwargs):
            if 'usuario_id' not in session:
                return redirect(url_for('login'))
            return fn(*args, **kwargs)
        return decorated_view
    return wrapper

@app.route('/')
@login_required()
def index():
    return render_template('index.html', nombre_usuario=session.get('nombre_usuario'))

@app.route('/asignar', methods=['GET', 'POST'])
@login_required()
def asignar_silla():
    if request.method == 'POST':
        nombre = request.form['nombre']
        cedula = request.form['cedula']
        clase = request.form['clase']
        posicion = request.form['posicion']
        resultado = reserva_service.asignar_silla(nombre, cedula, clase, posicion)
        return render_template('resultado.html', mensaje=resultado, volver=url_for('index'))
    return render_template('asignar_silla.html')

@app.route('/consultar', methods=['GET', 'POST'])
@login_required()
def consultar_reserva():
    if request.method == 'POST':
        cedula = request.form['cedula']
        resultado = reserva_service.consultar_reserva(cedula)
        return render_template('resultado.html', mensaje=resultado, volver=url_for('index'))
    return render_template('consultar_reserva.html')

@app.route('/eliminar', methods=['GET', 'POST'])
@login_required()
def eliminar_reserva():
    if request.method == 'POST':
        cedula = request.form['cedula']
        resultado = reserva_service.eliminar_reserva(cedula)
        return render_template('resultado.html', mensaje=resultado, volver=url_for('index'))
    return render_template('eliminar_reserva.html')

@app.route('/buscar', methods=['GET', 'POST'])
@login_required()
def buscar_pasajero():
    if request.method == 'POST':
        cedula = request.form['cedula']
        resultado = reserva_service.buscar_pasajero(cedula)
        return render_template('resultado.html', mensaje=resultado, volver=url_for('index'))
    return render_template('buscar_pasajero.html')

@app.route('/ocupacion')
@login_required()
def calcular_ocupacion():
    resultado = reserva_service.calcular_porcentaje_ocupacion()
    return render_template('ocupacion.html', ocupacion=resultado, volver=url_for('index'))

@app.route('/ventas_total')
@login_required()
def calcular_ventas_total():
    resultado = reserva_service.calcular_valor_total_ventas()
    return render_template('ventas_total.html', ventas=resultado, volver=url_for('index'))

@app.route('/ventas_promedio')
@login_required()
def calcular_ventas_promedio():
    resultado = reserva_service.calcular_valor_promedio_venta()
    return render_template('ventas_promedio.html', promedio=resultado, volver=url_for('index'))

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nombre_usuario = request.form['nombre_usuario']
        email = request.form['email']
        contrasena = request.form['contrasena']
        mensaje = reserva_service.registrar_usuario(nombre_usuario, contrasena, email)
        return render_template('resultado.html', mensaje=mensaje, volver=url_for('login'))
    return render_template('registro.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        contrasena = request.form['contrasena']
        usuario = reserva_service.iniciar_sesion(email, contrasena)
        if isinstance(usuario, Usuario):
            session['usuario_id'] = usuario.id_usuario
            session['nombre_usuario'] = usuario.nombre_usuario
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error=usuario)
    return render_template('login.html')

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(app.root_path, 'static/favicon.ico', mimetype='image/vnd.microsoft.icon')

if __name__ == '__main__':
    app.run(debug=True)