import pyodbc
from Models.Model_crud import Pasajero, Reserva, Silla, Usuario
from config import SERVER, DATABASE, USERNAME, PASSWORD, DRIVER

class DataAccess:
    def __init__(self):
        self.conexion = self._conectar_db()
        self.cursor = self.conexion.cursor()

    def _conectar_db(self):
        try:
            conexion_str = (
                f'DRIVER={DRIVER};'
                f'SERVER={SERVER}\\SQLEXPRESS;'
                f'DATABASE={DATABASE};'
            )
            if USERNAME and PASSWORD:
                conexion_str += f'UID={USERNAME};PWD={PASSWORD};'
            return pyodbc.connect(conexion_str)
        except pyodbc.Error as ex:
            sqlstate = ex.args[0]
            print(f"Error al conectar a la base de datos: {sqlstate}")
            return None

    def _cerrar_conexion(self):
        if self.conexion:
            self.conexion.close()
            print("Conexión a la base de datos cerrada.")

    def obtener_silla(self, id_silla):
        self.cursor.execute("SELECT IdSilla, Clase, Posicion, Precio FROM Sillas WHERE IdSilla = ?", id_silla)
        row = self.cursor.fetchone()
        if row:
            return Silla(row.IdSilla, row.Clase, row.Posicion, row.Precio)
        return None

    def obtener_todas_las_sillas(self):
        sillas = {}
        self.cursor.execute("SELECT IdSilla, Clase, Posicion, Precio FROM Sillas")
        for row in self.cursor.fetchall():
            silla = Silla(row.IdSilla, row.Clase, row.Posicion, row.Precio)
            sillas[row.IdSilla] = silla
        return sillas

    def existe_pasajero(self, cedula):
        self.cursor.execute("SELECT Cedula FROM Pasajeros WHERE Cedula = ?", cedula)
        return self.cursor.fetchone() is not None

    def agregar_pasajero(self, pasajero):
        try:
            self.cursor.execute("INSERT INTO Pasajeros (Cedula, Nombre) VALUES (?, ?)", pasajero.cedula, pasajero.nombre)
            self.conexion.commit()
            return True
        except pyodbc.Error as ex:
            sqlstate = ex.args[0]
            print(f"Error al agregar pasajero: {sqlstate}")
            self.conexion.rollback()
            return False

    def silla_esta_reservada(self, id_silla):
        self.cursor.execute("SELECT IdReserva FROM Reservas WHERE IdSilla = ?", id_silla)
        return self.cursor.fetchone() is not None

    def crear_reserva(self, id_silla, cedula_pasajero):
        try:
            self.cursor.execute("INSERT INTO Reservas (IdSilla, CedulaPasajero) VALUES (?, ?)", id_silla, cedula_pasajero)
            self.conexion.commit()
            return True
        except pyodbc.Error as ex:
            sqlstate = ex.args[0]
            print(f"Error al crear reserva: {sqlstate}")
            self.conexion.rollback()
            return False

    def obtener_reserva_por_cedula(self, cedula_pasajero):
        self.cursor.execute("""
            SELECT r.IdReserva, r.IdSilla, r.FechaReserva, s.Clase, s.Posicion, s.Precio, p.Nombre
            FROM Reservas r
            JOIN Sillas s ON r.IdSilla = s.IdSilla
            JOIN Pasajeros p ON r.CedulaPasajero = p.Cedula
            WHERE r.CedulaPasajero = ?
        """, cedula_pasajero)
        row = self.cursor.fetchone()
        if row:
            return {
                'id_reserva': row.IdReserva,
                'id_silla': row.IdSilla,
                'fecha_reserva': row.FechaReserva,
                'clase': row.Clase,
                'posicion': row.Posicion,
                'precio': row.Precio,
                'nombre_pasajero': row.Nombre,
                'cedula_pasajero': cedula_pasajero
            }
        return None

    def eliminar_reserva_por_cedula(self, cedula_pasajero):
        self.cursor.execute("DELETE FROM Reservas WHERE CedulaPasajero = ?", cedula_pasajero)
        rows_affected = self.cursor.rowcount
        self.conexion.commit()
        if rows_affected > 0:
            if not self._tiene_otras_reservas(cedula_pasajero):
                self._eliminar_pasajero_si_no_tiene_reservas(cedula_pasajero)
        return rows_affected

    def _tiene_otras_reservas(self, cedula_pasajero):
        self.cursor.execute("SELECT IdReserva FROM Reservas WHERE CedulaPasajero = ?", cedula_pasajero)
        return self.cursor.fetchone() is not None

    def _eliminar_pasajero_si_no_tiene_reservas(self, cedula_pasajero):
        try:
            self.cursor.execute("DELETE FROM Pasajeros WHERE Cedula = ?", cedula_pasajero)
            self.conexion.commit()
            print(f"Pasajero con cédula {cedula_pasajero} eliminado por no tener reservas.")
            return True
        except pyodbc.Error as ex:
            sqlstate = ex.args[0]
            print(f"Error al eliminar pasajero: {sqlstate}")
            self.conexion.rollback()
            return False

    def obtener_pasajero_por_cedula(self, cedula):
        self.cursor.execute("SELECT Nombre FROM Pasajeros WHERE Cedula = ?", cedula)
        row = self.cursor.fetchone()
        if row:
            return Pasajero(cedula, row.Nombre)
        return None

    def obtener_total_reservas(self):
        self.cursor.execute("SELECT COUNT(*) FROM Reservas")
        return self.cursor.fetchone()[0]

    def obtener_valor_total_ventas(self):
        self.cursor.execute("""
            SELECT SUM(s.Precio)
            FROM Reservas r
            JOIN Sillas s ON r.IdSilla = s.IdSilla
        """)
        result = self.cursor.fetchone()[0]
        return result if result else 0
    
    def obtener_usuario_por_nombre_usuario(self, nombre_usuario):
        self.cursor.execute("SELECT IdUsuario, NombreUsuario, ContrasenaHash, Email, FechaRegistro FROM Usuarios WHERE NombreUsuario = ?", nombre_usuario)
        row = self.cursor.fetchone()
        if row:
            return Usuario(row.IdUsuario, row.NombreUsuario, row.ContrasenaHash, row.Email, row.FechaRegistro)
        return None

    def agregar_usuario(self, usuario):
        try:
            self.cursor.execute("INSERT INTO Usuarios (NombreUsuario, ContrasenaHash, Email) VALUES (?, ?, ?)",
                                usuario.nombre_usuario, usuario.contrasena_hash, usuario.email)
            self.conexion.commit()
            return True
        except pyodbc.Error as ex:
            sqlstate = ex.args[0]
            print(f"Error al agregar usuario: {sqlstate}")
            self.conexion.rollback()
            return False
    
    def obtener_usuario_por_email(self, email):
        self.cursor.execute("SELECT IdUsuario, NombreUsuario, ContrasenaHash, Email, FechaRegistro FROM Usuarios WHERE Email = ?", email)
        row = self.cursor.fetchone()
        if row:
            return Usuario(row.IdUsuario, row.NombreUsuario, row.ContrasenaHash, row.Email, row.FechaRegistro)
        return None

    def cerrar(self):
        self._cerrar_conexion()