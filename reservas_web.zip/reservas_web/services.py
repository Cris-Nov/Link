from Models.Model_crud import Pasajero, Reserva, Silla, Usuario
from werkzeug.security import generate_password_hash, check_password_hash
from data_access import DataAccess

class ReservaService:
    def __init__(self):
        self.data_access = DataAccess()
        self.sillas = self.data_access.obtener_todas_las_sillas()

    def asignar_silla(self, nombre_pasajero, cedula_pasajero, preferencia_clase, preferencia_posicion):
        if not self.data_access.existe_pasajero(cedula_pasajero):
            pasajero = Pasajero(cedula_pasajero, nombre_pasajero)
            if not self.data_access.agregar_pasajero(pasajero):
                return "Error al registrar el pasajero."

        sillas_disponibles = [s for s in self.sillas.values() if s.clase == preferencia_clase and not self.data_access.silla_esta_reservada(s.id_silla)]

        sillas_filtradas = []
        if preferencia_clase == 'ejecutiva':
            sillas_filtradas = [s for s in sillas_disponibles if s.posicion in ['ventana', 'pasillo']]
        else:
            sillas_filtradas = [s for s in sillas_disponibles if s.posicion == preferencia_posicion]

        if not sillas_filtradas:
            return f"No hay sillas disponibles en clase {preferencia_clase} con la posición {preferencia_posicion}."

        silla_a_asignar = min(sillas_filtradas, key=lambda silla: silla.id_silla)

        if self.data_access.crear_reserva(silla_a_asignar.id_silla, cedula_pasajero):
            return f"Silla {silla_a_asignar.id_silla} ({silla_a_asignar.clase}, {silla_a_asignar.posicion}) asignada a {nombre_pasajero} (Cédula: {cedula_pasajero})."
        else:
            return "Error al asignar la silla."

    def consultar_reserva(self, cedula_pasajero):
        reserva_info = self.data_access.obtener_reserva_por_cedula(cedula_pasajero)
        if reserva_info:
            return f"Reserva ID: {reserva_info['id_reserva']}, Silla: {reserva_info['id_silla']} ({reserva_info['clase']}, {reserva_info['posicion']}), Precio: ${reserva_info['precio']:.2f}, Pasajero: {reserva_info['nombre_pasajero']} (Cédula: {reserva_info['cedula_pasajero']})"
        else:
            return f"No se encontró ninguna reserva para la cédula {cedula_pasajero}."

    def eliminar_reserva(self, cedula_pasajero):
        rows_affected = self.data_access.eliminar_reserva_por_cedula(cedula_pasajero)
        if rows_affected > 0:
            return f"Reserva para la cédula {cedula_pasajero} eliminada exitosamente."
        else:
            return f"No se encontró ninguna reserva para la cédula {cedula_pasajero} para eliminar."

    def buscar_pasajero(self, cedula_pasajero):
        pasajero = self.data_access.obtener_pasajero_por_cedula(cedula_pasajero)
        if pasajero:
            return f"Pasajero: {pasajero.nombre} (Cédula: {pasajero.cedula})"
        else:
            return f"No se encontró ningún pasajero con la cédula {cedula_pasajero}."

    def calcular_porcentaje_ocupacion(self):
        total_reservas = self.data_access.obtener_total_reservas()
        total_sillas = len(self.sillas)
        porcentaje = (total_reservas / total_sillas) * 100 if total_sillas > 0 else 0
        return f"Porcentaje de ocupación: {porcentaje:.2f}%"

    def calcular_valor_total_ventas(self):
        total_ventas = self.data_access.obtener_valor_total_ventas()
        return f"Valor total de ventas: ${total_ventas:.2f}"

    def calcular_valor_promedio_venta(self):
        total_reservas = self.data_access.obtener_total_reservas()
        total_ventas = self.data_access.obtener_valor_total_ventas()
        promedio = total_ventas / total_reservas if total_reservas > 0 else 0
        return f"Valor promedio de venta por pasajero: ${promedio:.2f}"
    
    def registrar_usuario(self, nombre_usuario, contrasena, email):
        if self.data_access.obtener_usuario_por_nombre_usuario(nombre_usuario):
            return "Nombre de usuario ya existe."
        if self.data_access.obtener_usuario_por_email(email):
            return "El correo electrónico ya está registrado."
        hashed_password = generate_password_hash(contrasena)
        nuevo_usuario = Usuario(nombre_usuario=nombre_usuario, contrasena_hash=hashed_password, email=email)
        if self.data_access.agregar_usuario(nuevo_usuario):
            return "Usuario registrado exitosamente."
        else:
            return "Error al registrar el usuario."

    def iniciar_sesion(self, email, contrasena):
        usuario = self.data_access.obtener_usuario_por_email(email)
        if usuario and check_password_hash(usuario.contrasena_hash, contrasena):
            return usuario
        else:
            return "Credenciales inválidas."

    def cerrar_conexion(self):
        self.data_access.cerrar()