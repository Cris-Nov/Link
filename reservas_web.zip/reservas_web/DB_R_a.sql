CREATE DATABASE R_a;
USE R_a;
GO

-- Creación de la tabla Pasajeros
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'Pasajeros')
BEGIN
    CREATE TABLE Pasajeros (
        Cedula VARCHAR(20) PRIMARY KEY,
        Nombre VARCHAR(100) NOT NULL
    );
END
GO

-- Creación de la tabla Sillas
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'Sillas')
BEGIN
    CREATE TABLE Sillas (
        IdSilla INT PRIMARY KEY,
        Clase VARCHAR(10) NOT NULL CHECK (Clase IN ('ejecutiva', 'economica')),
        Posicion VARCHAR(10) NOT NULL CHECK (Posicion IN ('ventana', 'pasillo', 'centro')),
        Precio DECIMAL(10, 2) NOT NULL
    );
END
GO

-- Creación de la tabla Reservas
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'Reservas')
BEGIN
    CREATE TABLE Reservas (
        IdReserva INT PRIMARY KEY IDENTITY(1,1),
        IdSilla INT UNIQUE NOT NULL,
        CedulaPasajero VARCHAR(20) NOT NULL,
        FechaReserva DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (IdSilla) REFERENCES Sillas(IdSilla),
        FOREIGN KEY (CedulaPasajero) REFERENCES Pasajeros(Cedula)
    );
END
GO
-- Creacion de la tabla de Usuarios
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Usuarios' and xtype='U')
BEGIN
    CREATE TABLE Usuarios (
        IdUsuario INT PRIMARY KEY IDENTITY(1,1),
        NombreUsuario VARCHAR(50) UNIQUE NOT NULL,
        ContrasenaHash VARCHAR(255) NOT NULL, -- Para almacenar la contraseña de forma segura (hasheada)
        Email VARCHAR(100) UNIQUE NOT NULL,
        FechaRegistro DATETIME DEFAULT GETDATE()
    );
END
GO

-- Inserción de las 8 sillas ejecutivas (IdSilla 1-8)
-- Asumiendo un orden: Ventana, luego Pasillo
IF NOT EXISTS (SELECT * FROM Sillas WHERE IdSilla BETWEEN 1 AND 8)
BEGIN
    INSERT INTO Sillas (IdSilla, Clase, Posicion, Precio) VALUES
    (1, 'ejecutiva', 'ventana', 150.00),
    (2, 'ejecutiva', 'pasillo', 150.00),
    (3, 'ejecutiva', 'ventana', 150.00),
    (4, 'ejecutiva', 'pasillo', 150.00),
    (5, 'ejecutiva', 'ventana', 150.00),
    (6, 'ejecutiva', 'pasillo', 150.00),
    (7, 'ejecutiva', 'ventana', 150.00),
    (8, 'ejecutiva', 'pasillo', 150.00);
END
GO

-- Inserción de las 42 sillas económicas (IdSilla 9-50)
-- Asumiendo un orden: Ventana, luego Pasillo, luego Centro
IF NOT EXISTS (SELECT * FROM Sillas WHERE IdSilla BETWEEN 9 AND 50)
BEGIN
    -- Bloque 1: Ventana (14 sillas)
    INSERT INTO Sillas (IdSilla, Clase, Posicion, Precio) VALUES
    (9, 'economica', 'ventana', 80.00), (10, 'economica', 'ventana', 80.00), (11, 'economica', 'ventana', 80.00),
    (12, 'economica', 'ventana', 80.00), (13, 'economica', 'ventana', 80.00), (14, 'economica', 'ventana', 80.00),
    (15, 'economica', 'ventana', 80.00), (16, 'economica', 'ventana', 80.00), (17, 'economica', 'ventana', 80.00),
    (18, 'economica', 'ventana', 80.00), (19, 'economica', 'ventana', 80.00), (20, 'economica', 'ventana', 80.00),
    (21, 'economica', 'ventana', 80.00), (22, 'economica', 'ventana', 80.00);

    -- Bloque 2: Pasillo (14 sillas)
    INSERT INTO Sillas (IdSilla, Clase, Posicion, Precio) VALUES
    (23, 'economica', 'pasillo', 80.00), (24, 'economica', 'pasillo', 80.00), (25, 'economica', 'pasillo', 80.00),
    (26, 'economica', 'pasillo', 80.00), (27, 'economica', 'pasillo', 80.00), (28, 'economica', 'pasillo', 80.00),
    (29, 'economica', 'pasillo', 80.00), (30, 'economica', 'pasillo', 80.00), (31, 'economica', 'pasillo', 80.00),
    (32, 'economica', 'pasillo', 80.00), (33, 'economica', 'pasillo', 80.00), (34, 'economica', 'pasillo', 80.00),
    (35, 'economica', 'pasillo', 80.00), (36, 'economica', 'pasillo', 80.00);

    -- Bloque 3: Centro (14 sillas)
    INSERT INTO Sillas (IdSilla, Clase, Posicion, Precio) VALUES
    (37, 'economica', 'centro', 70.00), (38, 'economica', 'centro', 70.00), (39, 'economica', 'centro', 70.00),
    (40, 'economica', 'centro', 70.00), (41, 'economica', 'centro', 70.00), (42, 'economica', 'centro', 70.00),
    (43, 'economica', 'centro', 70.00), (44, 'economica', 'centro', 70.00), (45, 'economica', 'centro', 70.00),
    (46, 'economica', 'centro', 70.00), (47, 'economica', 'centro', 70.00), (48, 'economica', 'centro', 70.00),
    (49, 'economica', 'centro', 70.00), (50, 'economica', 'centro', 70.00);
END
GO

-- Índices para optimizar las búsquedas
IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_Reservas_CedulaPasajero' AND object_id = OBJECT_ID('dbo.Reservas'))
BEGIN
    CREATE INDEX IX_Reservas_CedulaPasajero ON Reservas (CedulaPasajero);
END
GO

IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_Sillas_Clase_Posicion' AND object_id = OBJECT_ID('dbo.Sillas'))
BEGIN
    CREATE INDEX IX_Sillas_Clase_Posicion ON Sillas (Clase, Posicion);
END
GO