class Pasajero:
    def __init__(self, cedula, nombre):
        self.cedula = cedula
        self.nombre = nombre

class Reserva:
    def __init__(self, id_reserva, id_silla, cedula_pasajero, fecha_reserva=None):
        self.id_reserva = id_reserva
        self.id_silla = id_silla
        self.cedula_pasajero = cedula_pasajero
        self.fecha_reserva = fecha_reserva

class Silla:
    def __init__(self, id_silla, clase, posicion, precio):
        self.id_silla = id_silla
        self.clase = clase
        self.posicion = posicion
        self.precio = precio

    def __str__(self):
        return f"Silla ID: {self.id_silla}, Clase: {self.clase}, Posición: {self.posicion}, Precio: ${self.precio:.2f}"

class Usuario:
    def __init__(self, id_usuario=None, nombre_usuario=None, contrasena_hash=None, email=None, fecha_registro=None):
        self.id_usuario = id_usuario
        self.nombre_usuario = nombre_usuario
        self.contrasena_hash = contrasena_hash
        self.email = email
        self.fecha_registro = fecha_registro